from class_endereco import Endereco
from class_item_pedido import ItemPedido
from class_pedido import Pedido
from class_produto import Produto
from class_pessoa import *
from datetime import datetime

def menu_inicial():
    print('''
          MENU Inicial:
          [1] - Gerente
          [2] - Funcionarios
          [s] - Sair
          ''')
    return str(input("Escolha uma opção: "))

def menu_gerante():
    print('''
          MENU GERENTE:
          [1] - Cadastrar novo garçom
          [2] - Cadastrar novo atendente
          [3] - Cadastrar novo entregador
          [4] - Ver funcionaros cadastrados
          [s] - Sair
          ''')
    return str(input("Escolha uma opção: "))

def menu_principal():  # MENU PRINCIPAL
    print('''
        MENU Principal:
        [1] - Controle de vendas
        [2] - Cadastrar novo produto
        [3] - Remover um produto
        [4] - Pesquisar um produto
        [s] - Sair
    ''')
    return str(input('Escolha uma opção: '))

def menu_atendido():
    print('''
          Cliente atendido por:
          [1] - Garçom
          [2] - Atendente
          ''')
    return str(input("Escolha uma opção: "))

def menu_pedido():
    print('''
        MENU Vendas:
        [1] - Abrir novo pedido
        [2] - Adicionar item ao pedido
        [3] - Remover item do pedido
        [4] - Listar itens do pedido em detalhes
        [5] - Finalizar pedido e imprimir
        [s] - Sair
    ''')
    return str(input('Escolha uma opção: '))
#-------------------------------------------raphael-----------------------------------------------------#
def pedido_adicionar(local):
    # código pedido gerado automaticamente
    # alterado -> administrar pedido para entrega e pedido para consumo no local
    try:
        if local == '1':
            codigo_pedido = int(len(pedidos) + 1)  # a numeração do pedido começa de 1 até n
            print(f'O código do pedido é {codigo_pedido}')  # alterado -> mostrar o código do pedido
            endereco_pedido = None
            garcom, nome, codigo = pedido_atendimento_aux()
            pedido = Pedido(codigo_pedido, endereco_pedido) # create pedido object here
            pedido.garcom = garcom # Now you can assign garcom to pedido
            pedido.nome_garcom = nome
            pedido.tipo_funcionario_g = codigo
            
        elif local == '2':
            # código pedido gerado automaticamente
            endereco_pedido = cadastrar_endereco()
            codigo_pedido = int(len(pedidos) + 1)  # a numeração do pedido começa de 1 até n
            print(f'O código do pedido é {codigo_pedido}')  # alterado -> mostrar o código do pedido
            atendente, nome, codigo= pedido_atendimento_aux() #para salvar as informações da atendente q atendeu
            pedido = Pedido(codigo_pedido, endereco_pedido) # create pedido object here
            pedido.atendente = atendente
            pedido.nome_atendente = nome
            pedido.tipo_funcionario_a = codigo
        return pedido # return the created pedido object
    except:
        print('Erro ao criar pedido')
#-----------------------------------------------------------------------------------------------------#

def pedido_adicionar_item():
    try:
        int_pedido_selecionado = int(input('Informe o código do pedido para adicionar um novo item: '))
        if buscar_pedido_por_codigo(int_pedido_selecionado):
            # verificar se pedido existe
            pedido = pedidos[int_pedido_selecionado]
            int_codigo_produto = int(input('Informe o código do produto para adicionar ao pedido: '))
            produto = buscar_produto_por_codigo(int_codigo_produto)
            if pedido._status == 1: ### nao permitir alteração apos o pedido for finalizado by isaias
                print("Não é possível adicionar itens em um pedido finalizado.")
                return False
            if produto:
                int_quantidade_item = int(input('Informe a quantidade do item: '))
                novo_item_pedido = ItemPedido(produto, int_quantidade_item)
                pedido.adicionar_item_ao_pedido(novo_item_pedido)
            else:
                print("Não foi possível adicionar este produto, pois o código do produto não existe!")
            #return Pedido(codido_pedido, endereco_pedido)
        else:
            print("Pedido inexistente")
            return False
    except:
        print("Erro ao adicionar item ao pedido")
        
def pedido_remover_item():
    try:
        int_pedido_selecionado = int(input('Informe o código do pedido para remover um item selecionado: '))
        if buscar_pedido_por_codigo(int_pedido_selecionado):
            # verificar se pedido existe
            pedido = pedidos[int_pedido_selecionado]
            int_codigo_item = int(input('Informe o número do item para remover deste pedido ' + str(pedido._codigo_pedido) + ': '))
            if pedido._status == 1: ### nao permitir alteração apos o pedido for finalizado by isaias
                print("Não é possível remover itens de um pedido finalizado.")
                return False
            # verifica se número intem informado existe: não faz sentido remover item 5 se ele não existe
            #if pedido.quantidade_itens_pedido() <= int_codigo_item:
            pedido.remover_item_pedido(int_codigo_item)
        else:
            print("Pedido inexistente")
            return False
    except:
        print("Erro ao remover item do pedido")

def pedido_listar_items():
    try:
        int_pedido_selecionado = int(input('Informe o código do pedido para mais detalhes: '))
        if buscar_pedido_por_codigo(int_pedido_selecionado):
            # verificar se pedido existe
            pedido = pedidos[int_pedido_selecionado]
            pedido.toString()
        else:
            print("Pedido inexistente")
            return False
    except ValueError:
        print("Código do pedido deve ser um número inteiro!")
        print(ValueError)

def cadastrar_endereco():
    try:
        str_rua = (str(input('Informe a rua: '))).upper()
        int_num = int(input('Informe o número: '))
        str_complemento = (str(input('Informe o complemento do endereço: '))).upper()
        str_bairro = (str(input('Informe o bairro: '))).upper()
        endereco = Endereco(str_rua, int_num, str_complemento, str_bairro) #erro Endereco não está definido
        return endereco
    except:
        print("Erro ao cadastrar endereço")

def cadastrar_produto():
    try:
        int_codigo = int(input('Informe o código identificador do produto: '))
        str_nome = (str(input('Qual o nome/descrição do produto? '))).upper()
        flt_preco = float(input('Informe o valor (ex. 0.00): '))
        date_validade = (input('Informe a validade do produto (formato dd/mm/aaaa): '))
        date_validade = datetime.strptime(date_validade, '%d/%m/%Y')
        return Produto(int_codigo, str_nome, flt_preco, date_validade)
    except:
        print("Erro ao cadastrar produto")

def remover_produto():
    try:
        int_codigo_remocao = int(input('Informe o código do produto para remoção: '))
        produto_remover = estoque_produtos[int_codigo_remocao]
        print("Produto (" + produto_remover._descricao + ") removido!")
        del estoque_produtos[int_codigo_remocao]
    except:
        print("Produto não encontrado!")

def buscar_produto_por_codigo(int_codigo_produto):
    # Verifica se existe produto cadastrado
    for chave in estoque_produtos.keys():
        if chave == int_codigo_produto:
            return estoque_produtos[int_codigo_produto]
    return False

def buscar_pedido_por_codigo(int_codigo_pedido):
    # Verifica se existe produto cadastrado
    for chave in pedidos.keys():
        if chave == int_codigo_pedido:
            return pedidos[int_codigo_pedido]
    return False

def pedido_finalizar(): # add r.b.santos
    try:
        int_pedido_selecionado = int(input('Informe o código do pedido para finalizar: '))
        if buscar_pedido_por_codigo(int_pedido_selecionado):
            # verificar se pedido existe
            pedido = pedidos[int_pedido_selecionado]
            pedido.finalizar()
            return True
        else:
            print("Pedido inexistente.")
            return False
    except:
        print("Erro ao finalizar pedido.")

######### cadastrar funcionarios by isaias & raphael

def cadastrar_garcom(funcionarios, chave):
    try:
        nome = (input("Digite o nome do garçom: ")).upper()
        cpf = (input("Digite o CPF do garçom: ")).upper()
        porcentagem = 0.12
        garcom = Garcom(nome, cpf, porcentagem)
        funcionarios['1'][chave] = garcom
        return garcom
    except:
        print("Erro ao cadastrar garçom")

def cadastrar_atendente(funcionarios, chave):
    try:
        nome = (input("Digite o nome da atendente: ")).upper()
        cpf = (input("Digite o CPF da atendente: ")).upper()
        porcentagem = 0.10
        atendente = Atendente(nome, cpf, porcentagem)
        funcionarios['2'][chave] = atendente
        return atendente 
    except:
        print("Erro ao cadastrar atendente")

def cadastrar_entregador(funcionarios, chave):
    try:
        nome = (input("Digite o nome da entregador: ")).upper()
        cpf = (input("Digite o CPF da entregador: ")).upper()
        porcentagem = 0.05
        entregador = Entregador(nome, cpf, porcentagem )
        funcionarios['3'][chave] = entregador
        return entregador
    except:
        print("Erro ao cadastrar entregador")

def atendido_funcionario(tipo_funcionario, codigo, funcionarios):
    tipo_funcionario_capitalizado = tipo_funcionario.capitalize()
    if tipo_funcionario in funcionarios:
       if codigo in funcionarios[tipo_funcionario]:
            funcionario = funcionarios[tipo_funcionario][codigo]
            return tipo_funcionario_capitalizado, funcionario.nome, codigo
        
def pedido_atendimento_aux():
    opcao_escolhida_aux = menu_atendido()
    codigo_aux = input('Informe o codigo do funcionario: ')
    tipo_funcionario, nome, codigo = atendido_funcionario(opcao_escolhida_aux, codigo_aux, funcionarios)
    return tipo_funcionario, nome, codigo
##########################################################################################################

# Aplicação de exemplo disciplina POO - UFRB
# Sistema de controle de pedidos
# Professor Guilherme Braga Araújo
estoque_produtos = {}
pedidos = {}

funcionarios = {}
    
funcionarios['1'] = {}
funcionarios['2'] = {}
funcionarios['3'] = {}

# menu inicial
while True:
    #menu_gerente
    opcao_escolhida = menu_inicial()
    if opcao_escolhida == "1":
        opcao_escolhida = menu_gerante()
        if opcao_escolhida == "1":
            chave = input("Informe o codigo do funcionario: ")
            garcom = cadastrar_garcom(funcionarios, chave)
        elif opcao_escolhida == "2":
            chave = input("Informe o codigo do funcionario: ")
            atendente = cadastrar_atendente(funcionarios, chave)
        elif opcao_escolhida == "3":
            chave = input("Informe o codigo do funcionario: ")
            entregador = cadastrar_entregador(funcionarios, chave)
        elif opcao_escolhida == "4":
            Funcionarios.imprimir_funcionarios(funcionarios)
        else:
            break
    #menu_funcionario
    elif opcao_escolhida == "2":

        while True:
            # menu_principal
            opcao_escolhida = menu_principal()
            # verificando escolha
            # opc sair
            if (opcao_escolhida == "s"):
                break
            # opc 1
            elif (opcao_escolhida == "1"):
                while True:
                    opcao_escolhida = menu_pedido()
                    # opc menu vendas - novo pedido
                    if (opcao_escolhida == "1"):
                        local = input('''
                                      [1] - Pedido para consumir no local
                                      [2] - Pedido para entrega
                                      [s] - sair

                                      Escolha uma opção: ''')
                        if local == 's':
                          break
                        elif local == '1' or local == '2':
                          pedido = pedido_adicionar(local)
                        if (pedido):
                            # adiciona pedido ao sistema
                            pedidos[pedido._codigo_pedido] = pedido
                    # opc menu vendas - adicionar item
                    elif (opcao_escolhida == "2"):
                        pedido_adicionar_item()
                    elif (opcao_escolhida == "3"):
                        pedido_remover_item()
                    elif (opcao_escolhida == "4"):
                        pedido_listar_items()
                    elif (opcao_escolhida == "5"):
                        pedido_finalizar()
                    else:
                        # Volta para o menu principal
                        break

            # opc 2
            elif (opcao_escolhida == "2"):
                produto = cadastrar_produto()
                if (produto):
                    # adiciona produto ao nosso estoque
                    estoque_produtos[produto._codigo_produto] = produto
            # opc 3
            elif (opcao_escolhida == "3"):
                remover_produto()
            # opc 4
            elif (opcao_escolhida == "4"):
                int_codigo_produto = int(input('Informe o código do produto para busca: '))
                produto_pesquisa = buscar_produto_por_codigo(int_codigo_produto)
                if (produto_pesquisa):
                    print("--Produto encontrado--:")
                    print("-> Código= " + str(produto_pesquisa._codigo_produto))
                    print("-> Descricao= " + produto_pesquisa._descricao)
                    print("-> Valor= " + str(produto_pesquisa._preco))
                    print("-> Validade= " + str(produto_pesquisa._validade))
                else:
                    print("Produto nâo cadastrado/encontrado.")
            else:
                print("A opção escolhida é inválida.")
    elif opcao_escolhida == "s":
      break