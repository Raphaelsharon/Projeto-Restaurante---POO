class Pessoa:
    def __init__(self, nome: str, cpf: str, porcentagem_lucro: float = 0.0):
        self._nome = nome
        self._cpf = cpf
        self._porcentagem_lucro = porcentagem_lucro

    @property
    def nome(self) -> str:
        return self._nome

    @property
    def cpf(self) -> str:
        return self._cpf

    @property
    def porcentagem_lucro(self) -> float:
        return self._porcentagem_lucro

class Cliente(Pessoa):
    def __init__(self, nome: str, cpf: str, endereco: str):
        super().__init__(nome, cpf)
        self._endereco = endereco

    @property
    def endereco(self) -> str:
        return self._endereco

class Atendente(Pessoa):
    def __init__(self, nome: str, cpf: str, porcentagem_lucro: float):
        super().__init__(nome, cpf, porcentagem_lucro)


class Garcom(Pessoa):
    def __init__(self, nome: str, cpf: str, porcentagem_lucro: float):
        super().__init__(nome, cpf, porcentagem_lucro)

class Entregador(Pessoa):
    def __init__(self, nome: str, cpf: str, porcentagem_lucro: float):
        super().__init__(nome, cpf, porcentagem_lucro)

class Funcionarios():
    
    def imprimir_funcionario(tipo_funcionario, codigo, funcionarios):
        tipo_funcionario_capitalizado = tipo_funcionario.capitalize()
        if tipo_funcionario in funcionarios:
            if codigo in funcionarios[tipo_funcionario]:
                funcionario = funcionarios[tipo_funcionario][codigo]
                print(f"Tipo de funcionario: {tipo_funcionario_capitalizado}")
                print(f"Nome: {funcionario.nome} - Código: {codigo}")
            else:
                print(f"Código {codigo} não encontrado para o tipo {tipo_funcionario_capitalizado}.")
        else:
            print(f"Tipo de funcionario {tipo_funcionario_capitalizado} não encontrado.")

    def imprimir_funcionarios(funcionarios):
        for tipo_funcionario_capitalizado in funcionarios:
            for codigo in funcionarios[tipo_funcionario_capitalizado]:
                    funcionario = funcionarios[tipo_funcionario_capitalizado][codigo]
                    if tipo_funcionario_capitalizado == '1':
                        print(f"Tipo de funcionario: Garçom")
                        print(f"Nome: {funcionario.nome} - Código: {codigo}")
                    elif tipo_funcionario_capitalizado == '2':
                        print(f"Tipo de funcionario: Atendente")
                        print(f"Nome: {funcionario.nome} - Código: {codigo}")
                    elif tipo_funcionario_capitalizado == '3':
                        print(f"Tipo de funcionario: Entregador")
                        print(f"Nome: {funcionario.nome} - Código: {codigo}")
                    else:
                       print("Funcionario não encontrado.")